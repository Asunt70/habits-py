"""Global variables"""

# Database
DATABASE_PATH = "user/user_data.db"

# Config
CONFIG_PATH = "habitpy/config/config.json"

# user folder
USER_FOLDER_PATH = "user/"

# metadata
METADATA_PATH = "metadata.json"
