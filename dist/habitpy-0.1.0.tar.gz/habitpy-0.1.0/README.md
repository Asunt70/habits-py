# habits-py
 The intended purpose of this CLI application is to track habits we want to get more information.
 For example drinking your 2 liters of water as a habit is simple to say, but are you really making **any progress**?

 > Right now The project just started development if you want to suggest features feel free to open an issue

 ## Meant Features
 - Daily / Weekly habits
 - Custom Habits
 - Several units of tracking: Want to track exercise in minutes? **YES** or in yes / no responses? **ALSO YES**
 - Simple analize data: with analize 'habit' you will be able to see complex graphs to see how it's your progress
 - Export CSV: You can export all you data whenever you want as a CSV FILE, to see it in (EXCEL / SHEETS /ETC)

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/W7W318WNN8)
